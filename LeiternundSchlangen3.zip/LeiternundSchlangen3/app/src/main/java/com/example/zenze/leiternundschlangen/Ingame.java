package com.example.zenze.leiternundschlangen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.Random;

public class Ingame extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingame);
    }
    protected void roll(View v){
        int rand=new Random().nextInt(6);
        rand++;
        System.out.println("Würfle");
        //Remmaining Turn
    }
    protected void cheat(View v){
        //cheat
        System.out.println("Cheate");


    }
}
