package com.example.zenze.leiternundschlangen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.app.Activity;
import android.view.View;


public class NickNameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nickname);
    }
    protected void changeToMain(View view){

        Intent i=new Intent(getApplicationContext(),MainActivity.class);
        startActivity(i);

    }
}
