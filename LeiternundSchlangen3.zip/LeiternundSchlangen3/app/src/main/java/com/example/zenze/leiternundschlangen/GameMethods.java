package com.example.zenze.leiternundschlangen;
import java.util.Random;
import android.view.View;
/**
 * Created by Zenze on 18.04.2016.
 */
public class GameMethods {
    protected void roll(View v){
        int rand=new Random().nextInt(6);
        rand++;
        System.out.println("Würfle");
        //Remmaining Turn
    }
    protected void cheat(View v){
        //cheat
        System.out.println("Cheate");


    }

}
